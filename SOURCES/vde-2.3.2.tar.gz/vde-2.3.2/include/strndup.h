#ifndef STRNDUP_H__
#define STRNDUP_H__

#include <string.h>

#undef strndup

char *strndup(const char*, size_t);

#endif
