#ifndef VDECOMMON_H
#define VDECOMMON_H

#include <open_memstream.h>
#include <poll.h>
#include <strndup.h>

#include <cmdparse.h>
#include <canonicalize.h>

#endif
